<?php 
include 'koneksi/koneksi.php';
 ?>
<body class="bg">
	<div class="agile-main"> 
		<div class="menu-wrap" id="style-1"> 
			<nav class="top-nav">
				<ul class="icon-list">
					<li class="menu-title">Pariwisata Pemalang</li>
					<li><a class="active" href="index.php"><i class="glyphicon glyphicon-home"></i> Home </a></li>
					<li><a href="#"><i class="glyphicon glyphicon-map-marker"></i> Terdekat </a></li>
					<li><a href="view-wisata-alam.php"><i class="glyphicon glyphicon-leaf"></i> Alam </a></li>
					<li><a href="view-wisata-buatan.php"><i class="glyphicon glyphicon-retweet"></i>  Buatan </a></li>
					<li><a href="#"><i class="glyphicon glyphicon-thumbs-up"></i>  Favorite</a></li>
					<!-- <li><a href="#" class="menu"><i class="glyphicon glyphicon-duplicate"></i> pages<span class="glyphicon glyphicon-menu-down"></span></a>
						<ul class="nav-sub">
							<li><a href="#small-dialog" class="sign-in popup-top-anim"><i class="glyphicon glyphicon-user"></i> login</a></li>                                             
							<li><a href="#small-dialog1" class="sign-in popup-top-anim"><i class="glyphicon glyphicon-edit"></i> Sign Up</a></li>																								
							<li><a href="codes.html"><i class="glyphicon glyphicon-list-alt"></i> Short Codes</a></li> 
						</ul>
						<div class="clearfix"> </div>
						<script>
							$( "li a.menu" ).click(function() {
							$( "ul.nav-sub" ).slideToggle( 300, function() {
							// Animation complete.
							});
							});
						</script> 
					</li>
					<li><a href="contact.html"><i class="glyphicon glyphicon-envelope"></i> Contact </a></li> -->
				</ul>
			</nav>
						<button class="close-button" id="close-button">C</button>
		</div> 