				<div class="clearfix"> </div>
			</div>
			<div class="content">
				<!-- banner -->
				<div class="banner">
					<div id="kb" class="carousel kb_elastic animate_text kb_wrapper" data-ride="carousel" data-interval="6000" data-pause="hover">
						<!-- Wrapper-for-Slides -->
						<div class="carousel-inner" role="listbox"> 
							<!-- First-Slide -->
							<div class="item active">
								<div class="banner-img"> 
									<div class="carousel-caption kb_caption">
										<h3 data-animation="animated flipInX">Curug Bengkawah</h3>  
									</div>
								</div>
							</div> 
							<!-- Second-Slide -->
							<div class="item">
								<div class="banner-img banner-img1"> 
									<div class="carousel-caption kb_caption kb_caption_right">
										<h3 data-animation="animated flipInX">Pemandian Alam Moga</h3> 
									</div>
								</div>
							</div> 
							<!-- Third-Slide -->
							<div class="item">
								<div class="banner-img banner-img2"> 
									<div class="carousel-caption kb_caption kb_caption_center">
										<h3 data-animation="animated flipInX">Mojo Mangroove Adventure</h3> 
									</div>
								</div>
							</div> 

							<div class="item">
								<div class="banner-img banner-img3"> 
									<div class="carousel-caption kb_caption kb_caption_center">
										<h3 data-animation="animated flipInX">Rainbow Rafting River Pemalang</h3> 
									</div>
								</div>
							</div> 

							<div class="item">
								<div class="banner-img banner-img4"> 
									<div class="carousel-caption kb_caption kb_caption_center">
										<h3 data-animation="animated flipInX">Telaga Silating</h3> 
									</div>
								</div>
							</div> 

							<div class="item">
								<div class="banner-img banner-img5"> 
									<div class="carousel-caption kb_caption kb_caption_center">
										<h3 data-animation="animated flipInX">Widuri Water Park</h3> 
									</div>
								</div>
							</div> 
						</div> 
						<!-- Left-Button -->
						<a class="left carousel-control kb_control_left" href="#kb" role="button" data-slide="prev">
							<span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a> 
						<!-- Right-Button -->
						<a class="right carousel-control kb_control_right" href="#kb" role="button" data-slide="next">
							<span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a> 
					</div>
					<script src="js/custom.js"></script>
				</div>
				<!-- //banner -->