<!-- welcome -->
				<div class="welcome"> 
					<h3 class="w3ls-title">Welcome !</h3> 
					<p class="w3title-text">Selamat datang di aplikasi objek pariwisata Kota Pemalang, Jawa Tengah. </p>
					<div class="welcome-info">
						<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
							
							<div class="clearfix"> </div>
							<div id="myTabContent" class="tab-content">
								<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
									<div class="tabcontent-grids">
										<br>
										<br>
										<form action="#" method="post">
											<input type="search" name="Search" placeholder="Cari objek wisata..." required="">
											<button type="submit" class="btn btn-default" aria-label="Left Align">
												<span class="glyphicon glyphicon-search"></span>
											</button>
										</form>
										<!-- <a href="#small-dialog2" class="w3-search popup-top-anim"> Advanced Search</a> -->
									 </div>
								</div>
								
								</div>
															<!-- modal-three --> 
							<div id="small-dialog2" class="mfp-hide">
								<div class="login-modal w3ls-search">  
									<div class="booking-info">
										<h3><a href="main.html">Fortune Estates</a></h3>
									</div>
									<div class="login-form">
										<form action="#" method="post">
											<input type="text"  name="city name" placeholder="City Name..." required="">
											<input type="number" name="rooms" placeholder="Bed Rooms" min="1" required=""> 
											<input type="number" name="rooms" placeholder="Bath rooms" min="1"  required=""> 
											<div class="price">
												<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>
												<input type="text" placeholder="From" required="">
											</div>
											<div class="price price-right">
												<span class="glyphicon glyphicon-usd" aria-hidden="true"></span>
												<input type="text" placeholder="To" required="">
											</div>
											<select class="form-control"> 
												<option value="">Rental</option> 
												<option value="">Buy</option> 
												<option value="">sale</option>  
											</select>
											<input type="submit" value="Search">		
										</form>  
									</div>
								</div>
							</div>
							<!-- //modal-three --> 
						</div>  
					</div>  	
				</div> 
				<!-- //welcome -->