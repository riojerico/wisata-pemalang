<?php 
include 'layout-header.php';
include 'layout-sidebar.php';
include 'layout-modal.php';
include 'layout-banner.php';
include 'layout-welcome.php';
include 'layout-objek-terdekat.php';
include 'layout-brand-foot-js.php';

 ?>