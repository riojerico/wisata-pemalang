<?php
$con=mysqli_connect("localhost","root","","googlemap");

?>